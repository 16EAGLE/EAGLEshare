Information about the toos for R guides

A set of short guides to help you install and use some different R tools. 


